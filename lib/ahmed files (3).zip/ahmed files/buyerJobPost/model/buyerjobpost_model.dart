
import 'package:login_niche2/utils/flutterflow/flutter_flow_model.dart';
import 'package:flutter/material.dart';

class BuyerjobpostsModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    unfocusNode.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
